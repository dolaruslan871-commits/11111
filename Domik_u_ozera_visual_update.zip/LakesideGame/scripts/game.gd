extends Node3D
## MVP gameplay: collect, craft, fish, plant, upgrade tools, build cabin, save.

const SAVE_FILE := "user://lakeside_save.json"
const ITEM_NAMES := {
    "wood": "Дерево", "stone": "Камень", "line": "Леска",
    "fish": "Рыба", "wheat": "Пшеница",
    "seed_wheat": "Семена пшеницы", "seed_pine": "Семена сосны"
}

@onready var world = $World
@onready var player = $Player
@onready var hud = $HUD

var items: Dictionary = {
    "wood": 0, "stone": 0, "line": 0,
    "fish": 0, "wheat": 0, "seed_wheat": 0, "seed_pine": 0
}
var has_axe := false
var has_rod := false
var axe_level := 1
var rod_level := 1
var fishing_state := 0  # 0=idle, 1=waiting, 2=bite
var message := "Собери ветки и камни. Найди леску у озера!"
var _lake_check := 0.0

func _ready() -> void:
    world.setup(self)
    hud.setup(self)
    _load()
    notify("Добро пожаловать к озеру! Собирай ветки и камни.")

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        match event.keycode:
            KEY_E:
                action()
            KEY_F:
                fish()
            KEY_C:
                hud.toggle_crafting()
            KEY_P:
                plant("wheat")
            KEY_O:
                plant("pine")

func _physics_process(delta: float) -> void:
    # Keep the character on the bank instead of letting it walk over the lake.
    _lake_check += delta
    if _lake_check < 0.08:
        return
    _lake_check = 0.0
    if world.in_water(player.global_position):
        var away: Vector3 = player.global_position - world.LAKE_CENTER
        away.y = 0.0
        away = away.normalized()
        if away.length_squared() < 0.01:
            away = Vector3.LEFT
        var fixed: Vector3 = world.LAKE_CENTER + away * (world.LAKE_RADIUS - 0.10)
        player.global_position.x = fixed.x
        player.global_position.z = fixed.z

func add_item(item: String, amount: int) -> void:
    items[item] = int(items.get(item, 0)) + amount

func _can_pay(recipe: Dictionary) -> bool:
    for key in recipe:
        if int(items.get(key, 0)) < int(recipe[key]):
            return false
    return true

func _pay(recipe: Dictionary) -> void:
    for key in recipe:
        items[key] = int(items[key]) - int(recipe[key])

func craft_axe() -> void:
    if has_axe:
        notify("Топор уже есть — попробуй улучшить его")
        return
    var recipe := {"wood": 2, "stone": 2}
    if not _can_pay(recipe):
        notify("Для топора нужно: 2 дерева и 2 камня")
        return
    _pay(recipe)
    has_axe = true
    axe_level = 1
    notify("Каменный топор создан! Теперь можно рубить сосны.")
    _save()

func craft_rod() -> void:
    if has_rod:
        notify("Удочка уже в инвентаре")
        return
    var recipe := {"wood": 2, "line": 1}
    if not _can_pay(recipe):
        notify("Для удочки нужно: 2 дерева и 1 леска")
        return
    _pay(recipe)
    has_rod = true
    notify("Удочка готова! Подойди к берегу и нажми «Рыбачить».")
    _save()

func upgrade_axe() -> void:
    if not has_axe:
        notify("Сначала сделай топор")
        return
    if axe_level >= 3:
        notify("Топор уже максимального уровня")
        return
    var price := 3 if axe_level == 1 else 4
    if int(items["stone"]) < price:
        notify("Для заточки нужно %d камней" % price)
        return
    items["stone"] = int(items["stone"]) - price
    axe_level += 1
    notify("Топор заточен! Теперь его уровень: %d" % axe_level)
    _save()

func upgrade_rod() -> void:
    if not has_rod:
        notify("Сначала создай удочку")
        return
    if rod_level >= 3:
        notify("Удочка уже максимального уровня")
        return
    if int(items["wood"]) < 3:
        notify("Для улучшения удочки нужно 3 дерева")
        return
    items["wood"] = int(items["wood"]) - 3
    rod_level += 1
    notify("Удочка улучшена! Уровень: %d" % rod_level)
    _save()

func action() -> void:
    if fishing_state == 2:
        _hook_fish()
        return
    if fishing_state == 1:
        notify("Жди поклёвки...")
        return
    var nearby: Dictionary = world.nearest(player.global_position)
    if not nearby.is_empty():
        notify(world.interact(nearby))
        _save()
        return
    if world.near_lake(player.global_position):
        fish()
    else:
        notify("Подойди к предмету, дереву или берегу озера")

func fish() -> void:
    if fishing_state == 2:
        _hook_fish()
        return
    if fishing_state == 1:
        notify("Поплавок уже в воде. Ждём поклёвки...")
        return
    if not has_rod:
        notify("Сначала создай удочку: 2 дерева + 1 леска")
        return
    if not world.near_lake(player.global_position):
        notify("Для рыбалки нужно подойти к берегу озера")
        return
    fishing_state = 1
    notify("Заброс! Внимательно следи за поклёвкой...")
    await get_tree().create_timer(randf_range(1.6, 3.2)).timeout
    if not is_inside_tree() or fishing_state != 1:
        return
    fishing_state = 2
    notify("РЫБА КЛЮЁТ! Быстро нажми «ПОДСЕЧЬ»!")
    await get_tree().create_timer(3.1 + float(rod_level - 1) * 1.4).timeout
    if is_inside_tree() and fishing_state == 2:
        fishing_state = 0
        notify("Рыба сорвалась! Попробуй ещё раз.")

func _hook_fish() -> void:
    fishing_state = 0
    add_item("fish", 1)
    notify("Улов! +1 рыба. Теперь в рюкзаке: %d" % int(items["fish"]))
    _save()

func plant(kind: String) -> void:
    var seed := "seed_wheat" if kind == "wheat" else "seed_pine"
    if int(items[seed]) < 1:
        notify("Нет семян! Найди дикие колоски или сруби сосну")
        return
    var spot: Vector3 = player.global_position + player.forward_dir() * 2.2
    spot.y = 0.0
    if not world.can_plant(spot):
        notify("Здесь нельзя сажать — выбери свободную землю")
        return
    items[seed] = int(items[seed]) - 1
    world.add_plant(kind, spot)
    notify("Посажена %s! Рост: %d сек." % ["пшеница" if kind == "wheat" else "сосна", 45 if kind == "wheat" else 90])
    _save()

func build_hut() -> void:
    if world.hut_exists:
        notify("Домик уже построен! В будущем добавим мебель и улучшения")
        return
    var recipe := {"wood": 12, "stone": 4}
    if not _can_pay(recipe):
        notify("Для хижины нужно 12 дерева + 4 камня")
        return
    _pay(recipe)
    world.build_hut()
    notify("Ура! Домик готов. Найди его на расчищенном участке!")
    _save()

func notify(text_message: String) -> void:
    message = text_message
    hud.set_message(text_message)

func _save() -> void:
    var data := {
        "version": 1,
        "items": items,
        "has_axe": has_axe, "has_rod": has_rod,
        "axe_level": axe_level, "rod_level": rod_level,
        "player_position": [player.global_position.x, player.global_position.z],
        "removed": world.removed_ids,
        "plants": world.serialize_plants(),
        "built_hut": world.hut_exists
    }
    var file := FileAccess.open(SAVE_FILE, FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify(data))
        file.close()

func _load() -> void:
    if not FileAccess.file_exists(SAVE_FILE):
        return
    var file := FileAccess.open(SAVE_FILE, FileAccess.READ)
    if file == null:
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if typeof(parsed) != TYPE_DICTIONARY:
        return
    var saved_items: Dictionary = parsed.get("items", {})
    for item in items:
        items[item] = maxi(0, int(saved_items.get(item, 0)))
    has_axe = bool(parsed.get("has_axe", false))
    has_rod = bool(parsed.get("has_rod", false))
    axe_level = clampi(int(parsed.get("axe_level", 1)), 1, 3)
    rod_level = clampi(int(parsed.get("rod_level", 1)), 1, 3)
    var p: Array = parsed.get("player_position", [])
    if p.size() == 2:
        player.global_position = Vector3(clampf(float(p[0]), -32, 32), 1.2, clampf(float(p[1]), -32, 32))
    world.restore_state(parsed.get("removed", []), parsed.get("plants", []), bool(parsed.get("built_hut", false)))
