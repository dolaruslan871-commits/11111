extends SceneTree

func _initialize() -> void:
    create_timer(20).timeout.connect(func(): quit(2))
    run.call_deferred()

func check(ok: bool, label: String) -> void:
    if not ok:
        push_error("FAIL: " + label)
        quit(1)
        return
    print("PASS: " + label)

func find_item(world: Node, id: String) -> Dictionary:
    for item in world.interactables:
        if item["id"] == id:
            return item
    return {}

func run() -> void:
    var game = load("res://main.tscn").instantiate()
    root.add_child(game)
    await process_frame
    await process_frame
    game.player.global_position = Vector3(30, 1, 30)
    var hud = game.hud
    var touch := InputEventScreenTouch.new()
    touch.index = 0
    touch.pressed = true
    touch.position = hud.touch_targets[0]["button"].get_global_rect().get_center()
    hud._input(touch)
    check(game.player.touch_buttons["up"], "touch movement pressed")
    var action_touch := InputEventScreenTouch.new()
    action_touch.index = 1
    action_touch.pressed = true
    action_touch.position = hud.action_button.get_global_rect().get_center()
    hud._input(action_touch)
    check(game.player.touch_buttons["up"] and hud.active_touches.size() == 2, "simultaneous movement and action fingers")
    action_touch.pressed = false
    hud._input(action_touch)
    touch.pressed = false
    hud._input(touch)
    check(not game.player.touch_buttons["up"], "touch movement released")
    # Tests must use an isolated XDG_DATA_HOME; never run against a player's save.
    game.items = {"wood":0,"stone":0,"line":0,"fish":0,"wheat":0,"seed_wheat":0,"seed_pine":0}
    var world = game.world
    for id in ["wood_0", "wood_1", "stone_0", "stone_1"]:
        world.interact(find_item(world, id))
    game.craft_axe()
    check(game.has_axe and game.items["wood"] == 0 and game.items["stone"] == 0, "collect and craft axe")
    var tree: Dictionary = find_item(world, "tree_0")
    for i in range(5):
        world.interact(tree)
    check(game.items["wood"] == 4 and game.items["seed_pine"] == 1 and world.removed_ids.has("tree_0"), "chop detailed tree")
    world.interact(find_item(world, "fishing_line"))
    game.craft_rod()
    check(game.has_rod and game.items["wood"] == 2, "collect line and craft rod")
    game.player.global_position = Vector3(5.1,1, -5)
    game.fish()
    await create_timer(3.4).timeout
    check(game.fishing_state == 2, "fishing bite timer")
    game.fish()
    check(game.items["fish"] == 1, "hook fish")
    world.interact(find_item(world, "grain_0"))
    game.player.global_position = Vector3.ZERO
    game.plant("wheat")
    check(world.plants.size() == 1, "plant wheat")
    var plant: Dictionary = world.plants[0]
    plant["grow_at"] = int(Time.get_unix_time_from_system()) - 1
    world._render_plant(plant)
    world.interact(plant["item"])
    check(game.items["wheat"] == 2 and world.plants.is_empty(), "harvest mature wheat")
    game.plant("pine")
    check(world.plants.size() == 1, "plant pine")
    game.add_item("wood",12)
    game.add_item("stone",4)
    game.build_hut()
    check(world.hut_exists, "build hut")
    await create_timer(3.3).timeout
    game._save()
    var expected: Dictionary = game.items.duplicate()
    game.queue_free()
    await process_frame
    var restored = load("res://main.tscn").instantiate()
    root.add_child(restored)
    await process_frame
    check(restored.items == expected and restored.has_axe and restored.has_rod, "restore inventory and tools")
    check(restored.world.hut_exists and restored.world.removed_ids.has("tree_0"), "restore hut and removed tree")
    check(restored.world.plants.size() == 1 and restored.world.plants[0]["kind"] == "pine", "restore growing pine")
    restored.queue_free()
    await process_frame
    print("SMOKE COMPLETE")
    quit(0)
