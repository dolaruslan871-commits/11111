extends SceneTree
func _initialize() -> void:
    run.call_deferred()
func run() -> void:
    var game = load("res://main.tscn").instantiate()
    root.add_child(game)
    await create_timer(2).timeout
    game.player.set_process(false)
    game.player.camera.position = Vector3(-11, 14, 17)
    game.player.camera.look_at(Vector3(6, 0, -2))
    await process_frame
    await RenderingServer.frame_post_draw
    root.get_texture().get_image().save_png("res://docs/clearing.png")
    print("RENDER_CAPTURED")
    game.queue_free()
    await process_frame
    quit()
