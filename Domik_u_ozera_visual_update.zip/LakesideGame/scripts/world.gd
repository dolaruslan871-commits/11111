extends Node3D
## All props are simple procedural meshes — no paid assets needed.

const LAKE_CENTER := Vector3(13.0, 0.0, -5.0)
const LAKE_RADIUS := 7.0
const HUT_SITE := Vector3(-8.0, 0.0, 7.0)

var game
var interactables: Array[Dictionary] = []
var plants: Array[Dictionary] = []
var removed_ids: Array[String] = []
var hut_exists := false
var _plant_clock := 0.0
var material_cache: Dictionary = {}

func _ready() -> void:
    _build_environment()
    _populate_world()

func setup(parent_game: Node3D) -> void:
    game = parent_game

func _material(color: Color, transparent := false) -> StandardMaterial3D:
    var key := str(color) + str(transparent)
    if material_cache.has(key):
        return material_cache[key]
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.8
    if transparent:
        mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    material_cache[key] = mat
    return mat

func _mesh(parent: Node3D, primitive: PrimitiveMesh, pos: Vector3, color: Color) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    instance.mesh = primitive
    instance.position = pos
    instance.material_override = _material(color)
    parent.add_child(instance)
    return instance

func _box(parent: Node3D, center: Vector3, size: Vector3, color: Color, angle := 0.0) -> void:
    var mesh := BoxMesh.new()
    mesh.size = size
    var instance := _mesh(parent, mesh, center, color)
    instance.rotation.z = angle

func _sphere(parent: Node3D, center: Vector3, scale: Vector3, color: Color) -> void:
    var sphere := SphereMesh.new()
    sphere.radial_segments = 10
    sphere.rings = 5
    var instance := _mesh(parent, sphere, center, color)
    instance.scale = scale

func _cylinder(parent: Node3D, center: Vector3, radius: float, height: float, color: Color, tip := -1.0) -> void:
    var cylinder := CylinderMesh.new()
    cylinder.bottom_radius = radius
    cylinder.top_radius = tip if tip >= 0.0 else radius
    cylinder.height = height
    _mesh(parent, cylinder, center, color)

func _build_environment() -> void:
    var env := WorldEnvironment.new()
    env.environment = Environment.new()
    env.environment.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var atmosphere := ProceduralSkyMaterial.new()
    atmosphere.sky_top_color = Color("688c9e")
    atmosphere.sky_horizon_color = Color("e3dbbf")
    atmosphere.ground_horizon_color = Color("b8c5b7")
    atmosphere.ground_bottom_color = Color("657c66")
    sky.sky_material = atmosphere
    env.environment.sky = sky
    env.environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment.background_color = Color("bedfe3")
    env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.environment.ambient_light_color = Color("b9cbd2")
    env.environment.ambient_light_energy = 0.4
    add_child(env)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -38, 0)
    sun.light_energy = 0.9
    sun.light_color = Color("ffe4b1")
    sun.directional_shadow_max_distance = 45.0
    sun.shadow_bias = 0.04
    sun.shadow_enabled = true
    add_child(sun)
    _terrain()
    var bank_surface := SurfaceTool.new()
    bank_surface.begin(Mesh.PRIMITIVE_TRIANGLES)
    for sector in range(96):
        for index in [Vector2(0,0),Vector2(1,0),Vector2(0,1),Vector2(1,0),Vector2(1,1),Vector2(0,1)]:
            var angle: float = (sector + index.y) * TAU / 96.0
            var radius: float = (6.85 if index.x == 0 else 7.65) + sin(angle*5.0)*0.12 + cos(angle*3.0)*0.08
            bank_surface.set_normal(Vector3.UP)
            bank_surface.add_vertex(Vector3(cos(angle)*radius, 0.045, sin(angle)*radius))
    var bank := MeshInstance3D.new()
    bank.mesh = bank_surface.commit()
    bank.position = LAKE_CENTER
    bank.material_override = _material(Color("766b50"))
    add_child(bank)
    var water_surface := SurfaceTool.new()
    water_surface.begin(Mesh.PRIMITIVE_TRIANGLES)
    for ring in range(24):
        for sector in range(96):
            for index in [Vector2(0,0),Vector2(1,0),Vector2(0,1),Vector2(1,0),Vector2(1,1),Vector2(0,1)]:
                var radius: float = (ring + index.x) * LAKE_RADIUS / 24.0
                var angle: float = (sector + index.y) * TAU / 96.0
                water_surface.set_normal(Vector3.UP)
                radius *= 1.0 + sin(angle*5.0)*0.017 + cos(angle*3.0)*0.011
                water_surface.add_vertex(Vector3(cos(angle)*radius, 0, sin(angle)*radius))
    var lake := MeshInstance3D.new()
    lake.mesh = water_surface.commit()
    lake.position = LAKE_CENTER + Vector3(0,0.065,0)
    add_child(lake)
    var water_material := ShaderMaterial.new()
    water_material.shader = load("res://shaders/water.gdshader")
    lake.material_override = water_material
    _meadow_details()
    for i in range(34):
        var angle := i * TAU / 34.0
        var background_tree := Node3D.new()
        background_tree.position = Vector3(cos(angle)*39, terrain_height(cos(angle)*39, sin(angle)*39), sin(angle)*39)
        add_child(background_tree)
        _draw_tree(background_tree)
        background_tree.scale = Vector3.ONE * (1.2 + sin(i * 7.1) * 0.25)
    for i in range(24):
        var a := float(i) * TAU / 24.0
        var center := LAKE_CENTER + Vector3(cos(a) * 7.53, 0.05, sin(a) * 7.53)
        if i % 3 == 0:
            _sphere(self, center, Vector3(0.42, 0.2, 0.5), Color("c3b898"))

    # Small clearing decorations — these do not block movement.
    for i in range(48):
        var x := sin(float(i) * 23.13) * 28.0
        var z := cos(float(i) * 19.11) * 28.0
        if Vector2(x - LAKE_CENTER.x, z - LAKE_CENTER.z).length() < 9.0:
            continue
        if Vector2(x, z).length() < 5.0:
            continue
        _cylinder(self, Vector3(x, 0.13, z), 0.05, 0.24, Color("d9c777"), 0.01)

    # Mark the future hut site.
    _box(self, HUT_SITE + Vector3(0, 0.025, 0), Vector3(5, 0.05, 4), Color("796a4d"))

func _new_prop(id: String, kind: String, p: Vector3) -> Dictionary:
    var node := Node3D.new()
    node.name = id
    node.position = p
    add_child(node)
    var data := {"id": id, "kind": kind, "node": node, "hp": 5}
    interactables.append(data)
    return data

func _branch(parent: Node3D, start: Vector3, end: Vector3, radius: float) -> void:
    var limb := CylinderMesh.new()
    limb.bottom_radius = radius
    limb.top_radius = radius * 0.38
    limb.height = start.distance_to(end)
    limb.radial_segments = 6
    var part := _mesh(parent, limb, (start + end) * 0.5, Color("66503c"))
    part.quaternion = Quaternion(Vector3.UP, (end - start).normalized())

func _draw_tree(parent: Node3D, mature := true) -> void:
    var tree := Node3D.new()
    parent.add_child(tree)
    if not mature:
        tree.scale = Vector3.ONE * 0.23
    _branch(tree, Vector3.ZERO, Vector3(0.12, 5.2, 0), 0.27)
    for tier in range(5):
        var height := 1.7 + tier * 0.66
        var reach := (1.65 - tier * 0.25) * (1.0 + sin(parent.position.x * 3.2 + tier) * 0.12)
        for j in range(4):
            var angle := j * TAU / 4.0 + tier * 1.7
            var end := Vector3(cos(angle) * reach, height + 0.25, sin(angle) * reach)
            _branch(tree, Vector3(0, height, 0), end, 0.075 - tier * 0.009)
            var needles := SphereMesh.new()
            needles.radial_segments = 7
            needles.rings = 3
            var foliage := _mesh(tree, needles, end * Vector3(0.78, 1, 0.78), Color("42654b") if j % 2 == 0 else Color("527954"))
            foliage.scale = Vector3(reach * 0.95, 0.42, reach * 0.65)
    _sphere(tree, Vector3(0.1, 5.0, 0), Vector3(0.65, 0.85, 0.65), Color("5b8054"))
    _bake_tree(tree)

func _bake_tree(tree: Node3D) -> void:
    # Merge branches and foliage by shared material: four surfaces per tree.
    var surfaces: Dictionary = {}
    for child in tree.get_children():
        if not child is MeshInstance3D:
            continue
        var material: Material = child.material_override
        if not surfaces.has(material):
            var surface := SurfaceTool.new()
            surface.begin(Mesh.PRIMITIVE_TRIANGLES)
            surfaces[material] = surface
        var surface: SurfaceTool = surfaces[material]
        surface.append_from(child.mesh, 0, child.transform)
        child.queue_free()
    for material in surfaces:
        var merged := MeshInstance3D.new()
        merged.mesh = surfaces[material].commit()
        merged.material_override = material
        tree.add_child(merged)

func terrain_height(x: float, z: float) -> float:
    # Keep all original interaction sites level; hills frame the playable clearing.
    var edge := smoothstep(27.0, 36.0, Vector2(x, z).length())
    return edge * (0.9 + sin(x * 0.24) * 0.6 + cos(z * 0.22) * 0.5)

func _terrain() -> void:
    var surface := SurfaceTool.new()
    surface.begin(Mesh.PRIMITIVE_TRIANGLES)
    for x in range(-48, 48, 2):
        for z in range(-48, 48, 2):
            for offset in [Vector2(0,0), Vector2(2,0), Vector2(0,2), Vector2(2,0), Vector2(2,2), Vector2(0,2)]:
                var px: float = x + offset.x
                var pz: float = z + offset.y
                surface.add_vertex(Vector3(px, terrain_height(px, pz), pz))
    surface.generate_normals()
    var ground := MeshInstance3D.new()
    ground.mesh = surface.commit()
    var material := ShaderMaterial.new()
    material.shader = load("res://shaders/ground.gdshader")
    ground.material_override = material
    add_child(ground)
    ground.create_trimesh_collision()

func _meadow_details() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 7182
    var blade := QuadMesh.new()
    blade.size = Vector2(0.16, 0.48)
    var grass_material := StandardMaterial3D.new()
    grass_material.albedo_color = Color("697e3e")
    grass_material.cull_mode = BaseMaterial3D.CULL_DISABLED
    blade.material = grass_material
    var batch := MultiMesh.new()
    batch.transform_format = MultiMesh.TRANSFORM_3D
    batch.instance_count = 1800
    batch.mesh = blade
    for i in range(batch.instance_count):
        var p := Vector3(rng.randf_range(-31,31), 0, rng.randf_range(-31,31))
        if Vector2(p.x - 13, p.z + 5).length() < 8.1 or absf(p.z - sin(p.x * 0.22)*1.3) < 1.2 or p.distance_to(HUT_SITE) < 3.5:
            batch.set_instance_transform(i, Transform3D(Basis().scaled(Vector3.ZERO), Vector3.ZERO))
            continue
        p.y = terrain_height(p.x, p.z) + 0.24
        var basis := Basis(Vector3.UP, rng.randf_range(0, TAU))
        batch.set_instance_transform(i, Transform3D(basis, p))
    var meadow := MultiMeshInstance3D.new()
    meadow.multimesh = batch
    meadow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(meadow)
    for i in range(65):
        var p := Vector3(rng.randf_range(-24,24), 0, rng.randf_range(-24,24))
        if Vector2(p.x-13,p.z+5).length() < 8.0:
            continue
        _cylinder(self, p + Vector3(0,0.13,0), 0.018, 0.26, Color("60753c"))
        _sphere(self, p + Vector3(0,0.28,0), Vector3(0.13,0.06,0.13), Color("e2c886") if i % 2 == 0 else Color("b9a2ba"))

func _populate_world() -> void:
    var spots: Array[Vector2] = [
        Vector2(-12,-11), Vector2(-19,-6), Vector2(-17,6), Vector2(-13,15),
        Vector2(-3,-17), Vector2(3,-19), Vector2(10,-18), Vector2(19,-17),
        Vector2(24,-8), Vector2(25,1), Vector2(21,10), Vector2(12,14),
        Vector2(4,15), Vector2(-1,13), Vector2(-22,17), Vector2(-25,-18),
        Vector2(-7,-7), Vector2(-6,0), Vector2(3,9), Vector2(-16,24),
        Vector2(18,23), Vector2(29,17), Vector2(27,-22), Vector2(-27,0)
    ]
    for i in range(spots.size()):
        var tree := _new_prop("tree_%d" % i, "tree", Vector3(spots[i].x, 0, spots[i].y))
        _draw_tree(tree["node"])

    var twig_spots: Array[Vector2] = [
        Vector2(1,-1),Vector2(-2,-2),Vector2(3,2),Vector2(0,4),
        Vector2(-5,2),Vector2(2,6),Vector2(-5,-5),Vector2(7,-3),
        Vector2(-9,-3),Vector2(6,8),Vector2(-12,1),Vector2(9,10),
        Vector2(-4,10),Vector2(-19,4)
    ]
    for i in range(twig_spots.size()):
        var twig := _new_prop("wood_%d" % i, "wood", Vector3(twig_spots[i].x,0,twig_spots[i].y))
        _box(twig["node"], Vector3(0,0.13,0), Vector3(1.05,0.21,0.21), Color("8b6746"), 0.1)

    var stone_spots: Array[Vector2] = [
        Vector2(-1,1),Vector2(4,-1),Vector2(-4,-1),Vector2(2,4),
        Vector2(-6,5),Vector2(5,5),Vector2(-9,0),Vector2(7,8),
        Vector2(-11,6),Vector2(12,4),Vector2(-3,9),Vector2(1,10),
        Vector2(-17,0),Vector2(-11,-8),Vector2(20,6),Vector2(8,-12)
    ]
    for i in range(stone_spots.size()):
        var rock := _new_prop("stone_%d" % i, "stone", Vector3(stone_spots[i].x, 0, stone_spots[i].y))
        _sphere(rock["node"], Vector3(0, 0.25, 0), Vector3(0.4, 0.27, 0.42), Color("8f9694"))

    var line := _new_prop("fishing_line", "line", Vector3(5.2, 0, -4.0))
    _box(line["node"], Vector3(0, 0.3, 0), Vector3(0.9, 0.6, 0.65), Color("966841"))
    _cylinder(line["node"], Vector3(0, 0.68, 0), 0.2, 0.09, Color("e5e7d7"))

    for i in range(6):
        var grain := _new_prop("grain_%d" % i, "wild_wheat", Vector3(-3.0 + i * 1.6, 0, 6.7 + sin(float(i) * 3.0)))
        _draw_wheat(grain["node"], true)

func _draw_wheat(parent: Node3D, mature: bool) -> void:
    for j in range(3):
        var x := -0.25 + float(j) * 0.25
        _cylinder(parent, Vector3(x, 0.32 if mature else 0.14, 0), 0.045, 0.65 if mature else 0.28, Color("879853"))
        if mature:
            _sphere(parent, Vector3(x, 0.72, 0), Vector3(0.13, 0.25, 0.13), Color("d5b45f"))

func near_lake(pos: Vector3) -> bool:
    var d := Vector2(pos.x - LAKE_CENTER.x, pos.z - LAKE_CENTER.z).length()
    return d <= LAKE_RADIUS + 3.1 and d >= LAKE_RADIUS - 1.8

func in_water(pos: Vector3) -> bool:
    return Vector2(pos.x - LAKE_CENTER.x, pos.z - LAKE_CENTER.z).length() < LAKE_RADIUS - 0.20

func nearest(pos: Vector3, radius := 2.65) -> Dictionary:
    var nearest_item: Dictionary = {}
    var best := radius
    for item in interactables:
        var node: Node3D = item["node"]
        if not is_instance_valid(node) or node.is_queued_for_deletion():
            continue
        var d := pos.distance_to(Vector3(node.global_position.x, pos.y, node.global_position.z))
        if d < best:
            best = d
            nearest_item = item
    return nearest_item

func remove_item(item: Dictionary, permanently := true) -> void:
    interactables.erase(item)
    if permanently and not removed_ids.has(item["id"]):
        removed_ids.append(item["id"])
    var node: Node3D = item["node"]
    if is_instance_valid(node):
        node.queue_free()

func interact(item: Dictionary) -> String:
    var kind: String = item["kind"]
    if kind == "wood":
        game.add_item("wood", 1)
        remove_item(item)
        return "Подобрана ветка: +1 дерево"
    if kind == "stone":
        game.add_item("stone", 1)
        remove_item(item)
        return "Подобран камень: +1"
    if kind == "line":
        game.add_item("line", 1)
        remove_item(item)
        return "Найдена рыболовная леска!"
    if kind == "wild_wheat":
        game.add_item("seed_wheat", 2)
        remove_item(item)
        return "Собраны семена пшеницы: +2"
    if kind == "tree":
        if not game.has_axe:
            return "Сначала сделай каменный топор"
        item["hp"] = int(item["hp"]) - game.axe_level
        if int(item["hp"]) > 0:
            return "Рубим дерево... осталось %d прочности" % int(item["hp"])
        game.add_item("wood", 4)
        game.add_item("seed_pine", 1)
        remove_item(item)
        return "Дерево срублено! +4 дерево, +1 семечко сосны"
    if kind == "planted_wheat" or kind == "planted_pine":
        var plant: Dictionary = {}
        for p in plants:
            if p["id"] == item["id"]:
                plant = p
                break
        if plant.is_empty():
            return "Растение не найдено"
        if not plant["grown"]:
            return "Растение ещё растёт"
        if kind == "planted_wheat":
            game.add_item("wheat", 2)
            game.add_item("seed_wheat", 2)
            plants.erase(plant)
            remove_item(item, false)
            return "Урожай! +2 пшеницы, +2 семени"
        if not game.has_axe:
            return "Для взрослой сосны нужен топор"
        item["hp"] = int(item["hp"]) - game.axe_level
        if int(item["hp"]) > 0:
            return "Рубим выращенную сосну..."
        game.add_item("wood", 4)
        game.add_item("seed_pine", 1)
        plants.erase(plant)
        remove_item(item, false)
        return "Сосна срублена! +4 дерево, +1 семечко"
    return ""

func can_plant(pos: Vector3) -> bool:
    if in_water(pos) or Vector2(pos.x - LAKE_CENTER.x, pos.z - LAKE_CENTER.z).length() < LAKE_RADIUS + 0.7:
        return false
    if pos.distance_to(HUT_SITE) < 4.5:
        return false
    for item in interactables:
        if item["kind"] in ["tree", "planted_wheat", "planted_pine"]:
            var node: Node3D = item["node"]
            if is_instance_valid(node) and node.global_position.distance_to(pos) < 2.1:
                return false
    return true

func add_plant(kind: String, pos: Vector3, grow_at: int = 0) -> void:
    if grow_at == 0:
        grow_at = int(Time.get_unix_time_from_system()) + (45 if kind == "wheat" else 90)
    var uid := "plant_%d" % (plants.size() + Time.get_ticks_msec())
    var item := _new_prop(uid, "planted_" + kind, Vector3(pos.x, 0, pos.z))
    var data := {"id": uid, "kind": kind, "pos": [pos.x, pos.z], "grow_at": grow_at, "grown": false, "item": item}
    plants.append(data)
    _render_plant(data)

func _render_plant(plant: Dictionary) -> void:
    var now := int(Time.get_unix_time_from_system())
    var grown: bool = now >= int(plant["grow_at"])
    plant["grown"] = grown
    var node: Node3D = plant["item"]["node"]
    if not is_instance_valid(node):
        return
    for c in node.get_children():
        c.queue_free()
    if plant["kind"] == "wheat":
        _draw_wheat(node, grown)
    else:
        _draw_tree(node, grown)

func _process(delta: float) -> void:
    _plant_clock += delta
    if _plant_clock < 1.0:
        return
    _plant_clock = 0.0
    var now := int(Time.get_unix_time_from_system())
    for plant in plants:
        if not plant["grown"] and now >= int(plant["grow_at"]):
            _render_plant(plant)
            if is_instance_valid(game):
                game.notify("Посадки подросли — проверь огород!")

func serialize_plants() -> Array:
    var data := []
    for p in plants:
        data.append({"kind": p["kind"], "pos": p["pos"], "grow_at": p["grow_at"]})
    return data

func restore_state(removed: Array, saved_plants: Array, built_hut: bool) -> void:
    removed_ids.clear()
    for id in removed:
        removed_ids.append(str(id))
    for item in interactables.duplicate():
        if removed_ids.has(str(item["id"])):
            remove_item(item, false)
    for entry in saved_plants:
        if typeof(entry) != TYPE_DICTIONARY:
            continue
        var p: Array = entry.get("pos", [])
        if p.size() != 2:
            continue
        var kind := str(entry.get("kind", "wheat"))
        if kind not in ["wheat", "pine"]:
            continue
        add_plant(kind, Vector3(float(p[0]), 0, float(p[1])), int(entry.get("grow_at", 0)))
    if built_hut:
        build_hut()

func build_hut() -> void:
    if hut_exists:
        return
    hut_exists = true
    var h := Node3D.new()
    h.name = "Cabin"
    h.position = HUT_SITE
    add_child(h)
    _box(h, Vector3(0, 0.17, 0), Vector3(4.6, 0.34, 3.6), Color("76523d"))
    _box(h, Vector3(-2.2, 1.45, 0), Vector3(0.22, 2.65, 3.6), Color("ae774d"))
    _box(h, Vector3(2.2, 1.45, 0), Vector3(0.22, 2.65, 3.6), Color("ae774d"))
    _box(h, Vector3(0, 1.45, 1.75), Vector3(4.4, 2.65, 0.20), Color("a8754f"))
    _box(h, Vector3(-1.5, 1.45, -1.75), Vector3(1.4, 2.65, 0.20), Color("a8754f"))
    _box(h, Vector3(1.5, 1.45, -1.75), Vector3(1.4, 2.65, 0.20), Color("a8754f"))
    _box(h, Vector3(0, 2.42, -1.75), Vector3(1.7, 0.71, 0.2), Color("a8754f"))
    _box(h, Vector3(-1.18, 3.49, 0), Vector3(2.75, 0.25, 4.25), Color("4b6659"), 0.55)
    _box(h, Vector3(1.18, 3.49, 0), Vector3(2.75, 0.25, 4.25), Color("4b6659"), -0.55)
    _box(h, Vector3(-2.25, 1.75, 0), Vector3(0.05, 0.8, 0.9), Color("c9e3d9"))
