extends CanvasLayer
## Landscape touch HUD; buttons also work with the mouse on a Mac.

var game
var root: Control
var bag_label: Label
var tip_label: Label
var action_button: Button
var fishing_button: Button
var craft_panel: PanelContainer
var _update_clock := 0.0
var touch_targets: Array[Dictionary] = []
var active_touches: Dictionary = {}

func _ready() -> void:
    root = Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(root)
    var theme := Theme.new()
    var panel := StyleBoxFlat.new()
    panel.bg_color = Color(0.09, 0.16, 0.15, 0.92)
    panel.set_corner_radius_all(16)
    panel.content_margin_left = 12
    panel.content_margin_right = 12
    panel.content_margin_top = 8
    panel.content_margin_bottom = 8
    theme.set_stylebox("panel", "PanelContainer", panel)
    var button_style := panel.duplicate() as StyleBoxFlat
    button_style.bg_color = Color("385a51")
    button_style.border_color = Color("a9ba90")
    button_style.set_border_width_all(1)
    theme.set_stylebox("normal", "Button", button_style)
    var pressed := button_style.duplicate() as StyleBoxFlat
    pressed.bg_color = Color("73855b")
    theme.set_stylebox("pressed", "Button", pressed)
    theme.set_color("font_color", "Label", Color("f0e5cb"))
    theme.set_color("font_color", "Button", Color("f0e5cb"))
    root.theme = theme
    _create_status()
    _create_controls()
    _create_crafting()
    get_viewport().size_changed.connect(_apply_safe_area)
    _apply_safe_area()

func setup(parent_game) -> void:
    game = parent_game
    refresh()

func _make_button(parent: Node, text_value: String, position: Vector2, dimensions: Vector2) -> Button:
    var button := Button.new()
    button.text = text_value
    button.position = position
    button.size = dimensions
    button.add_theme_font_size_override("font_size", 20)
    button.focus_mode = Control.FOCUS_NONE
    button.modulate.a = 0.94
    parent.add_child(button)
    return button

func _create_status() -> void:
    var header := PanelContainer.new()
    header.anchor_left = 0.01
    header.anchor_right = 0.99
    header.anchor_top = 0.012
    header.anchor_bottom = 0.012
    header.offset_top = 0
    header.offset_bottom = 112
    header.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(header)
    var margin := MarginContainer.new()
    margin.add_theme_constant_override("margin_left", 16)
    margin.add_theme_constant_override("margin_right", 16)
    margin.add_theme_constant_override("margin_top", 8)
    margin.add_theme_constant_override("margin_bottom", 8)
    header.add_child(margin)
    bag_label = Label.new()
    bag_label.add_theme_font_size_override("font_size", 19)
    bag_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    margin.add_child(bag_label)

    var tip_background := PanelContainer.new()
    tip_background.anchor_left = 0.25
    tip_background.anchor_right = 0.75
    tip_background.anchor_top = 1.0
    tip_background.anchor_bottom = 1.0
    tip_background.offset_top = -98
    tip_background.offset_bottom = -18
    tip_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(tip_background)
    tip_label = Label.new()
    tip_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    tip_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    tip_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    tip_label.add_theme_font_size_override("font_size", 22)
    tip_background.add_child(tip_label)

func _create_controls() -> void:
    var pad := Control.new()
    pad.anchor_left = 0.0
    pad.anchor_right = 0.0
    pad.anchor_top = 1.0
    pad.anchor_bottom = 1.0
    pad.offset_left = 24
    pad.offset_right = 214
    pad.offset_top = -239
    pad.offset_bottom = -30
    pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(pad)
    _dpad_button(pad, "▲", Vector2(70,0), "up")
    _dpad_button(pad, "▼", Vector2(70,120), "down")
    _dpad_button(pad, "◀", Vector2(0,60), "left")
    _dpad_button(pad, "▶", Vector2(140,60), "right")

    var actions := Control.new()
    actions.anchor_left = 1.0
    actions.anchor_right = 1.0
    actions.anchor_top = 1.0
    actions.anchor_bottom = 1.0
    actions.offset_left = -300
    actions.offset_right = -18
    actions.offset_top = -217
    actions.offset_bottom = -34
    actions.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(actions)
    action_button = _make_button(actions, "Подобрать / использовать", Vector2(0, 0), Vector2(282, 79))
    action_button.pressed.connect(_handle_action)
    touch_targets.append({"button": action_button, "direction": "action"})
    fishing_button = _make_button(actions, "🎣 Рыбачить", Vector2(0, 94), Vector2(282, 68))
    fishing_button.pressed.connect(_handle_fishing)
    touch_targets.append({"button": fishing_button, "direction": "fish"})

func _dpad_button(parent: Control, glyph: String, pos: Vector2, direction: String) -> void:
    var b := _make_button(parent, glyph, pos, Vector2(66, 66))
    touch_targets.append({"button": b, "direction": direction})
    b.button_down.connect(func() -> void:
        if game != null:
            game.player.set_touch_button(direction, true)
    )
    b.button_up.connect(func() -> void:
        if game != null:
            game.player.set_touch_button(direction, false)
    )

func _create_crafting() -> void:
    var menu_button := Button.new()
    menu_button.text = "🛠 Рюкзак / Крафт"
    menu_button.add_theme_font_size_override("font_size", 21)
    menu_button.anchor_left = 1.0
    menu_button.anchor_right = 1.0
    menu_button.anchor_top = 0.0
    menu_button.anchor_bottom = 0.0
    menu_button.offset_left = -243
    menu_button.offset_right = -15
    menu_button.offset_top = 126
    menu_button.offset_bottom = 181
    root.add_child(menu_button)
    menu_button.pressed.connect(toggle_crafting)

    craft_panel = PanelContainer.new()
    craft_panel.anchor_left = 1.0
    craft_panel.anchor_right = 1.0
    craft_panel.anchor_top = 0.0
    craft_panel.anchor_bottom = 0.0
    craft_panel.offset_left = -343
    craft_panel.offset_right = -15
    craft_panel.offset_top = 188
    craft_panel.offset_bottom = 677
    craft_panel.visible = false
    root.add_child(craft_panel)
    var outer := MarginContainer.new()
    for margin_name in ["margin_top", "margin_bottom", "margin_left", "margin_right"]:
        outer.add_theme_constant_override(margin_name, 8)
    craft_panel.add_child(outer)
    var scroll := ScrollContainer.new()
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    outer.add_child(scroll)
    var layout := VBoxContainer.new()
    layout.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    layout.add_theme_constant_override("separation", 7)
    scroll.add_child(layout)
    var title := Label.new()
    title.text = "МАСТЕРСКАЯ И ХОЗЯЙСТВО"
    title.add_theme_font_size_override("font_size", 20)
    layout.add_child(title)
    _recipe_button(layout, "🪓 Топор • 2 дерева + 2 камня", "axe")
    _recipe_button(layout, "🎣 Удочка • 2 дерева + леска", "rod")
    _recipe_button(layout, "🪨 Точить топор • 3/4 камня", "sharpen")
    _recipe_button(layout, "✨ Улучшить удочку • 3 дерева", "rod_upgrade")
    _recipe_button(layout, "🌾 Посадить пшеницу • 1 семя", "wheat")
    _recipe_button(layout, "🌲 Посадить сосну • 1 семя", "pine")
    _recipe_button(layout, "🏠 Домик • 12 дерева + 4 камня", "hut")
    var footer := Label.new()
    footer.text = "ПК: WASD — ходьба, правая мышь — камера; E — действие, F — рыбалка, C — крафт."
    footer.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    footer.add_theme_font_size_override("font_size", 15)
    layout.add_child(footer)

func _recipe_button(parent: VBoxContainer, label_text: String, recipe: String) -> void:
    var b := Button.new()
    b.text = label_text
    b.custom_minimum_size = Vector2(0, 49)
    b.add_theme_font_size_override("font_size", 17)
    b.focus_mode = Control.FOCUS_NONE
    parent.add_child(b)
    b.pressed.connect(func() -> void:
        _craft(recipe)
    )

func _craft(recipe: String) -> void:
    if game == null:
        return
    match recipe:
        "axe": game.craft_axe()
        "rod": game.craft_rod()
        "sharpen": game.upgrade_axe()
        "rod_upgrade": game.upgrade_rod()
        "wheat": game.plant("wheat")
        "pine": game.plant("pine")
        "hut": game.build_hut()
    refresh()

func toggle_crafting() -> void:
    craft_panel.visible = not craft_panel.visible

func _handle_action() -> void:
    if game != null:
        game.action()
        refresh()

func _handle_fishing() -> void:
    if game != null:
        game.fish()
        refresh()

func set_message(value: String) -> void:
    if is_instance_valid(tip_label):
        tip_label.text = value

func _process(delta: float) -> void:
    if game == null:
        return
    _update_clock += delta
    if _update_clock >= 0.25:
        _update_clock = 0.0
        refresh()

func refresh() -> void:
    if game == null or not is_instance_valid(bag_label):
        return
    var inv: Dictionary = game.items
    var axe: String = "топор ур.%d" % game.axe_level if game.has_axe else "нет топора"
    var rod: String = "удочка ур.%d" % game.rod_level if game.has_rod else "нет удочки"
    bag_label.text = "🌲 ДОМИК У ОЗЕРА     🪵 %d   🪨 %d   🧵 %d   🐟 %d   🌾 %d\nСемена: пшеница %d • сосна %d      Инструменты: %s • %s" % [
        int(inv["wood"]), int(inv["stone"]), int(inv["line"]), int(inv["fish"]), int(inv["wheat"]),
        int(inv["seed_wheat"]), int(inv["seed_pine"]), axe, rod
    ]
    var nearby: Dictionary = game.world.nearest(game.player.global_position)
    if game.fishing_state == 2:
        action_button.text = "🐟 ПОДСЕЧЬ!"
        fishing_button.text = "🐟 ПОДСЕЧЬ!"
    elif game.fishing_state == 1:
        action_button.text = "Ждём поклёвки..."
        fishing_button.text = "🎣 Заброшено"
    elif not nearby.is_empty():
        var kind: String = nearby["kind"]
        var labels := {
            "wood": "Собрать ветку", "stone": "Подобрать камень", "line": "Взять леску",
            "tree": "Рубить сосну", "wild_wheat": "Собрать семена",
            "planted_wheat": "Собрать / проверить", "planted_pine": "Рубить / проверить"
        }
        action_button.text = labels.get(kind, "Взаимодействовать")
        fishing_button.text = "🎣 Рыбачить"
    elif game.world.near_lake(game.player.global_position):
        action_button.text = "🎣 Рыбачить"
        fishing_button.text = "🎣 Рыбачить"
    else:
        action_button.text = "Подойти к предмету"
        fishing_button.text = "🎣 Рыбачить"

# Track each finger independently; mouse signals remain available on desktop.
func _input(event: InputEvent) -> void:
    if game == null or not event is InputEventScreenTouch:
        return
    if not event.pressed:
        if active_touches.has(event.index):
            var direction: String = active_touches[event.index]
            active_touches.erase(event.index)
            if direction in ["up", "down", "left", "right"]:
                game.player.set_touch_button(direction, direction in active_touches.values())
            get_viewport().set_input_as_handled()
        return
    for target in touch_targets:
        var button: Button = target["button"]
        if button.is_visible_in_tree() and button.get_global_rect().has_point(event.position):
            # Let an open crafting panel receive its own overlapping touches.
            if craft_panel.visible and craft_panel.get_global_rect().has_point(event.position):
                return
            var direction: String = target["direction"]
            active_touches[event.index] = direction
            if direction == "action":
                _handle_action()
            elif direction == "fish":
                _handle_fishing()
            else:
                game.player.set_touch_button(direction, true)
            get_viewport().set_input_as_handled()
            return

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT and game != null:
        active_touches.clear()
        for direction in ["up", "down", "left", "right"]:
            game.player.set_touch_button(direction, false)

func _apply_safe_area() -> void:
    if not OS.has_feature("mobile"):
        return
    var safe := DisplayServer.get_display_safe_area()
    var screen := DisplayServer.screen_get_size()
    if screen.x <= 0 or screen.y <= 0 or safe.size.x <= 0:
        return
    var viewport := get_viewport().get_visible_rect().size
    var ratio := viewport / Vector2(screen)
    root.offset_left = safe.position.x * ratio.x
    root.offset_top = safe.position.y * ratio.y
    root.offset_right = -(screen.x - safe.end.x) * ratio.x
    root.offset_bottom = -(screen.y - safe.end.y) * ratio.y
