extends CharacterBody3D
## Third-person controller, mouse drag or right-screen swipe rotates view.

const SPEED := 5.5
const GRAVITY := 18.0

var touch_buttons: Dictionary = {"up": false, "down": false, "left": false, "right": false}
var mobile_look_index := -1
var camera_yaw := -1.05
var body_mesh: Node3D
var limbs: Array[Node3D] = []
var stride := 0.0
var target_yaw := -1.05
var camera: Camera3D

func _ready() -> void:
    position = Vector3(0, 1.2, 0)
    var collider := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.38
    capsule.height = 1.7
    collider.shape = capsule
    add_child(collider)

    body_mesh = Node3D.new()
    add_child(body_mesh)
    _body_part(body_mesh, Vector3(0,0.17,0), Vector3(0.66,0.7,0.36), Color("547d79"))
    _body_part(body_mesh, Vector3(0,0.72,0), Vector3(0.38,0.42,0.35), Color("d6aa83"))
    _body_part(body_mesh, Vector3(0,0.94,0.02), Vector3(0.43,0.16,0.4), Color("604c39"))
    _body_part(body_mesh, Vector3(0,0.15,0.28), Vector3(0.47,0.55,0.24), Color("9d704c"))
    _body_part(body_mesh, Vector3(0,0.92,-0.13), Vector3(0.48,0.08,0.33), Color("604c39"))
    for side in [-1, 1]:
        _body_part(body_mesh, Vector3(side*0.09,0.74,-0.18), Vector3(0.035,0.045,0.02), Color("343632"))
    _body_part(body_mesh, Vector3(0,0.28,-0.19), Vector3(0.06,0.22,0.02), Color("d4c29a"))
    for side in [-1, 1]:
        var arm := Node3D.new()
        arm.position = Vector3(side * 0.43,0.43,0)
        body_mesh.add_child(arm)
        _body_part(arm, Vector3(0,-0.24,0), Vector3(0.2,0.5,0.23), Color("547d79"))
        _body_part(arm, Vector3(0,-0.52,0), Vector3(0.18,0.18,0.2), Color("d6aa83"))
        limbs.append(arm)
    for side in [-1, 1]:
        var leg := Node3D.new()
        leg.position = Vector3(side * 0.18,-0.16,0)
        body_mesh.add_child(leg)
        _body_part(leg, Vector3(0,-0.27,0), Vector3(0.26,0.55,0.27), Color("454e50"))
        _body_part(leg, Vector3(0,-0.59,-0.06), Vector3(0.29,0.17,0.43), Color("574332"))
        limbs.append(leg)

    camera = Camera3D.new()
    camera.current = true
    camera.fov = 65.0
    get_parent().call_deferred("add_child", camera)

func _body_part(parent: Node3D, center: Vector3, dimensions: Vector3, color: Color) -> void:
    var part := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = dimensions
    part.mesh = mesh
    part.position = center
    part.material_override = _mat(color)
    parent.add_child(part)

func _mat(color: Color) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = 0.9
    return material

func set_touch_button(direction: String, held: bool) -> void:
    touch_buttons[direction] = held

func forward_dir() -> Vector3:
    return Vector3(-sin(camera_yaw), 0, -cos(camera_yaw))

func _physics_process(delta: float) -> void:
    camera_yaw = lerp_angle(camera_yaw, target_yaw, 1.0 - exp(-12.0 * delta))
    var horizontal := 0.0
    var vertical := 0.0
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP) or touch_buttons["up"]:
        vertical += 1.0
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN) or touch_buttons["down"]:
        vertical -= 1.0
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT) or touch_buttons["left"]:
        horizontal -= 1.0
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT) or touch_buttons["right"]:
        horizontal += 1.0
    var forward := forward_dir()
    var right := Vector3(cos(camera_yaw), 0, -sin(camera_yaw))
    var movement := (forward * vertical + right * horizontal).normalized()
    velocity.x = movement.x * SPEED
    velocity.z = movement.z * SPEED
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    else:
        velocity.y = -0.2
    move_and_slide()
    var walking := Vector2(velocity.x, velocity.z).length() / SPEED
    stride += delta * 10.0 * walking
    for i in range(limbs.size()):
        var swing := sin(stride + (PI if i % 2 == 0 else 0.0)) * 0.55 * walking
        limbs[i].rotation.x = lerpf(limbs[i].rotation.x, swing if i < 2 else -swing, minf(delta * 15, 1))
    body_mesh.position.y = absf(sin(stride)) * 0.045 * walking
    global_position.x = clampf(global_position.x, -32.5, 32.5)
    global_position.z = clampf(global_position.z, -32.5, 32.5)
    if movement.length_squared() > 0.001:
        body_mesh.rotation.y = lerp_angle(body_mesh.rotation.y, atan2(-movement.x, -movement.z), minf(delta * 12.0, 1.0))

func _process(delta: float) -> void:
    if is_instance_valid(camera):
        var follow := global_position + Vector3(sin(camera_yaw) * 7.3, 5.0, cos(camera_yaw) * 7.3)
        camera.global_position = camera.global_position.lerp(follow, minf(delta * 8.0, 1.0))
        camera.look_at(global_position + Vector3(0, 0.9, 0), Vector3.UP)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        target_yaw -= event.relative.x * 0.006
    if event is InputEventScreenTouch:
        if event.pressed and event.position.x > get_viewport().get_visible_rect().size.x * 0.53 and mobile_look_index == -1:
            mobile_look_index = event.index
        elif not event.pressed and event.index == mobile_look_index:
            mobile_look_index = -1
    if event is InputEventScreenDrag and event.index == mobile_look_index:
        target_yaw -= event.relative.x * 0.008
